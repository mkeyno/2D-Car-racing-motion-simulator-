



//////////////////////////////////
var _Connection;
var  Step=10;  
var Radar_Status=false;
//var host = window.document.location.host.replace(/:.*/, '');
var link="ws://"+location.host+"/ws";
/*
								 var telegram=new Image();        
									 telegram.src="data:image/png;base64,iVBOR..";	 
  document.getElementById("tel").src=telegram.src;

window.onload = function (){   
						    Wave( "images/logo.png",'flag',8,200); 
						    setTimeout( initialize , 200);  
						   }
url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABPSURBVFhH7dGxDYAwFENBD5P9Z2CzRKKn5GOhK17l5iRnXdnN3cDkua93QEDAXwCbczEgIOAEsDkXAwICTgCbczEgIOAEsDkXAwICvrpnHyDoiCaNG9QFAAAAAElFTkSuQmCC')								   
*/

//////////////////////////////////
function initialize (){
ini_ws();	
document.getElementById('_status').style.display = "block";

}
function ini_ws()
{
 
 _Connection = new WebSocket( link, ['arduino']); 
_Connection.onerror = function (error) {	
										document.getElementById('_link').style.backgroundColor ="#FFA500";
										//alert('Conection Error '+'\n'+link);
										}
_Connection.close = function (error) {	document.getElementById('_link').style.backgroundColor ="#FFE4E1";} //gray
_Connection.onopen = function (evt) {  
									var newdate=new Date();
									var C_date=pad2(newdate.getFullYear())+pad2(newdate.getDay()) +pad2(newdate.getDate()) ;
									var C_sec=newdate.getSeconds()+ newdate.getMinutes()*60 + newdate.getHours()*3600; 
									_Connection.send('SGT=' + C_date + C_sec); //15
									document.getElementById('_link').style.backgroundColor ="#7FFF00"; // grenn
									document.getElementById('current_data').value=newdate;
									}
_Connection.onmessage = function(INCOME){parsing(INCOME.data); }	 
	
setInterval(check_WS, 500);	
}
 function check_WS(){//if(!_Connection ||
  
      if(  _Connection.readyState == 3 ) {document.getElementById('_link').style.backgroundColor ="#FFA500"; ini_ws();}
else  if(  _Connection.readyState == 0 ) {document.getElementById('_link').style.backgroundColor ="#DC143C";  } 
else  if(  _Connection.readyState == 2 ) {document.getElementById('_link').style.backgroundColor ="#FF0000";  }
  }
  
function parsing(_income)
 {
 
	var param_array = _income.split("@"); 
	 len=param_array.length;
	    if(param_array[0]=='RST') {  //alert(param_array) ;
								    						 
									document.getElementById("welcome").value="welcome "+param_array[2];//welcome LoginUser									 									
									 
									if(WifiMode=='S') document.getElementById("wifimode").value="اتصال به وای فای";
									else              document.getElementById("wifimode").value="وای فای مستقل";
									 
													
									document.getElementById("localip").value=param_array[3]; //MyIP		                                    
									document.getElementById("hostID").value="local"+param_array[5]; //Hostname 
									document.getElementById("_SSID").value=param_array[6]; //ST_ssid
									document.getElementById("AP_name").value=param_array[7]; //AP_ssid
									document.getElementById("serverip").value=param_array[10]; //Master_IP
									
									 
								
								 ///------------------------------------ network setting  page	WFM
								    if(WifiMode=='S') document.getElementById("WFM").options[1].selected = true;
									else              document.getElementById("WFM").options[0].selected = true;
									document.getElementById("SHN").value=param_array[5]; //Hostname
									document.getElementById("APN").value=param_array[7];//AP_ssid
									
								 
				 	           						
										
								 
						}
  else if(param_array[0]=='SVE')  {
	                              // var old= document.getElementById("savesetting").style.backgroundColor;
	                                document.getElementById("savesetting").style.backgroundColor='#00FF00';
								   setTimeout(back2normalColor,3000,"savesetting","#D4D0C8"); 
								   }	
  else if(param_array[0]=='RAD')  {//WS.text(MainWSclinet,"RAD@"+String(Sweep_Step)+"@"+String(S_list[Sweep_Step]));
	                              // draw_line(parseInt(param_array[1]),parseInt(param_array[2]))	;	
                                   // document.getElementById("distance").value=param_array[2];								   
                                    } 
  else if(param_array[0]=='DIR')  {	
									//show_tab("Dir"+param_array[1],"direct");  	
									}							
  else if(param_array[0]=='VOL')  {	
								//	document.getElementById("voltage").value=param_array[1];		
									}	
									
 } 
 
   function draw_line( step,  value){
   
   var alfa=step*Math.PI/Step;//Math.floor((Math.random()*Math.PI) + 0);   
   var x=200-Math.floor(value*Math.cos(alfa));
   var y=200- Math.floor(value*Math.sin(alfa)); 
   
   var RADAR = document.getElementById('RadarL');
				var  nline = document.createElementNS('http://www.w3.org/2000/svg', 'line');
					 nline.setAttribute("class", "hideable");
					 nline.setAttribute("x1", 200);
					 nline.setAttribute("y1", 200);
					 nline.setAttribute("x2", x);
					 nline.setAttribute("y2", y); 
					 nline.setAttribute("stroke", "#24C000");
					 nline.setAttribute("stroke-width", 30);
					 nline.setAttribute("stroke-linecap", "butt"); //butt, round,square 
       RADAR.appendChild(nline);
    if(step==9) { while (RADAR.firstChild) {  RADAR.removeChild(RADAR.firstChild);} }  
   }
 ////////////////////////////////////	page status  			//////////////////////////////////////////////

 function SetNetwork(){
	var     ssid=document.getElementById('_ssid').value;
	var netpass=document.getElementById('_netpass').value;	
  var command  = "SNW="+ ssid + "@" +netpass ;   //http://192.168.4.1/process?code=RNI&ssid=ssid+pass&poz=poz
   _Connection.send(command);	
}

function show_user_list()
{
		var _AJX=createXHR();    
   _AJX.onreadystatechange = function(){   
										  if(_AJX.readyState == 4)
										  {  
											var div = document.getElementById('userlist');
                                                div.innerHTML = _AJX.responseText;			// id of list box in code = 							
										  }
									   }
  var command  = "?code=USL";                                        //http://192.168.4.1/process?code=RUL
   _AJX.open("GET",  "/process" + command, true);
   _AJX.send(null);
	
}
function RestartHTML()
{
var _AJX=createXHR();    
				   _AJX.onreadystatechange = function(){   
														  if(_AJX.readyState == 4)
														  {  
														  }
													   }
				  var command  = "?code=RST&"
				   _AJX.open("GET", "/process" + command, true);
				   _AJX.send(null); 	
	
}
function AddUser()
{
	var a= document.getElementById("_username").value;
	var b= document.getElementById("_password").value;
	var e = document.getElementById("_userType");
    var c = e.options[e.selectedIndex].text;
	//var line=a+','+b +',' +c;
	 var count=document.getElementById("ListUserListBox").length;
	 if(count<6){
					var _AJX=createXHR();    
				   _AJX.onreadystatechange = function(){   
														  if(_AJX.readyState == 4)
														  {  
															show_user_list();//var recieved =_AJX.responseText;  alert(recieved);							
														  }
													   }
				  var command  = "?code=AUS&user=" + a + '&pass='+b + '&scop='+c; //http://192.168.4.1/process?code=RAU&user=user&pass=pass&scop=scop
				   _AJX.open("GET", "/process" + command, true);
				   _AJX.send(null); 
				}
	else alert("Exceed max user numbers")
}
function RemoveUser()
{
	var e = document.getElementById("ListUserListBox");
	var count=document.getElementById("ListUserListBox").length;
	if(count>1){	
				var index=e.selectedIndex;
				var _AJX=createXHR();    
			   _AJX.onreadystatechange = function(){   
													  if(_AJX.readyState == 4)
													  {  
														show_user_list();//var recieved =_AJX.responseText;  alert(recieved);							
													  }
												   }
			  var command  = "?code=RUS&index=" + index; //http://192.168.4.1/process?code=RRU&index=index
			   _AJX.open("GET","/process" + command, true);
			   _AJX.send(null); 
			}
	else alert("Atleast need one user")
}
function ScanNetwork()
{
	
	 var _AJX=createXHR();    
   _AJX.onreadystatechange = function(){   
										  if(_AJX.readyState == 4)
										  {  
											var div = document.getElementById('netScanResult');
                                                div.innerHTML = _AJX.responseText;			 							
										  }
									   }
  var command  = "?code=NET";                                        //http://192.168.4.1/process?code=RSN
   _AJX.open("GET","/process" + command, true);
   _AJX.send(null);
	
}
////////////////////////////////////	page config			//////////////////////////////////////////////
 function createXHR() 
{ 
		try   {
			                 return new XMLHttpRequest();
			  } 
	catch (e) {
						try {
							 return new ActiveXObject("Microsoft.XMLHTTP");
							} 
				catch (e)  {
							 return new ActiveXObject("Msxml2.XMLHTTP");
						  }
              }
}

 function change_color(id)
 {
	if(_Connection.readyState==1)		document.getElementById(id).style.backgroundColor = "LawnGreen";	
    else 	                           {document.getElementById('_link').style.backgroundColor ="#FFA500"; 
										document.getElementById(id).style.backgroundColor = "Red";}
	 setTimeout(back2normalColor,3000,id); 
 }

 function back2normal(){ document.getElementById('HTTP').className="HTTP"; }
   function back2normalColor(id,old) { 	 document.getElementById(id).style.backgroundColor = old; 	  }

function selectssid_pass()
{
    var e = document.getElementById("_netList");
	if(e.selectedIndex>0)
	{	
	var strUser = e.options[e.selectedIndex].text;
	var S=strUser.split(",")
	var ssid=S[0].trim()
	document.getElementById('_ssid').value=ssid;
	}
}

 function CheckIP(_Obj)
  {
    ValidIP = false; 
	var IPText=_Obj.value;
	
    ipParts = IPText.split(".");
    if(ipParts.length==4){
						  for(i=0;i<4;i++){							 
											TheNum = parseInt(ipParts[i]);
											if(TheNum >= 0 && TheNum <= 255){}
											else{break;}											 
										  }
						  if(i==4)ValidIP=true; 
						}
	if(!ValidIP)	alert('Wrong Format')				
  }

function parse_line()
{
	var e = document.getElementById("listfile");
    var line = e.options[e.selectedIndex].text;
	var myArray=line.split("/");
    var num=myArray.length; 
if(num>2){ 
         document.getElementById("_path").value='/'+myArray[1]; 
		 document.getElementById("_file").value='/'+myArray[2]; 
		 }
else     {
		 document.getElementById("_path").value='/'; 
		 document.getElementById("_file").value=myArray[1];
         }
}

function parse_line_and_put_inform()
{
	var e = document.getElementById("ListUserListBox");
    var line = e.options[e.selectedIndex].text;
	var myArray=line.split(",");
    var num=myArray.length; 
     // alert (myArray + '\n'+num)options[i].selected = true   selectedIndex                  
	 document.getElementById("_username").value=myArray[0]; 
	 document.getElementById("_password").value=myArray[1]; 		

}

function showselecteditem()
{
var e = document.getElementById("Comboboxtest");
var strUser = e.options[e.selectedIndex].text;
var num=strUser.split("/").length;
if(num>2){ patch=strUser.split("/")[1]; file=strUser.split("/")[2];
             alert (patch+'      '+file  )}
else  {file=strUser.split("/")[1]; alert ('only file '+file  )}
}

function secondsToTime(secs)
{
   // secs = Math.round(secs)*10;
    var hours = Math.floor(secs / (60 * 60));

    var divisor_for_minutes = secs % (60 * 60);
    var minutes = Math.floor(divisor_for_minutes / 60);

    var divisor_for_seconds = divisor_for_minutes % 60;
     var seconds = Math.ceil(divisor_for_seconds);
	 if(hours<10) hours= "0"+hours;
    if(minutes<10) minutes= "0"+minutes;
     if(seconds<10) seconds= "0"+seconds;
    return hours+":"+minutes +":"+seconds
       
}
function Wave(_image,_canvas,_amp,_speed)
{
//  alert("wave")  	
var h = new Image;      		
	h.onload = function(){
							var flag = document.getElementById(_canvas);
							var amp =_amp;
							flag.width  = h.width;
							flag.height = h.height + amp*2;
							flag.getContext('2d').drawImage(h,0,amp,h.width,h.height);
							flag.style.marginLeft = -(flag.width/2)+'px';
							flag.style.marginTop  = -(flag.height/2)+'px';
							var timer = waveFlag( flag, h.width/10, amp ,_speed);
						};
	h.src =_image ;
function waveFlag( canvas, wavelength, amplitude, period, shading, squeeze )
{
				if (!squeeze)    squeeze    = 0;
				if (!shading)    shading    = 100;
				if (!period)     period     = 400;
				if (!amplitude)  amplitude  = 10;
				if (!wavelength) wavelength = canvas.width/10;

				var fps = 30;
				var ctx = canvas.getContext('2d');
				var   w = canvas.width, h = canvas.height;
				var  od = ctx.getImageData(0,0,w,h).data;
				// var ct = 0, st=new Date;
				return setInterval(function(){
												var id = ctx.getImageData(0,0,w,h);
												var  d = id.data;
												var now = (new Date)/period;
												for (var y=0;y<h;++y){
													var lastO=0,shade=0;
													var sq = (y-h/2)*squeeze;
													for (var x=0;x<w;++x){
														var px  = (y*w + x)*4;
														var pct = x/w;
														var o   = Math.sin(x/wavelength-now)*amplitude*pct;
														var y2  = y + (o+sq*pct)<<0;
														var opx = (y2*w + x)*4;
														shade = (o-lastO)*shading;
														d[px  ] = od[opx  ]+shade;
														d[px+1] = od[opx+1]+shade;
														d[px+2] = od[opx+2]+shade;
														d[px+3] = od[opx+3];
														lastO = o;
													}
												}
												ctx.putImageData(id,0,0);		
												// if ((++ct)%100 == 0) console.log( 1000 * ct / (new Date - st));
											},1000/fps);
	}	
} 
  
function pad2(number) { return (number < 10 ? '0' : '') + number }
function convert2second(s){	return parseInt(s.substring(0,2))*3600+parseInt(s.substring(3,5))*60+parseInt(s.substring(6));}
 function show_tab( id, my_class) 
 {
  
   var i;
    var x = document.getElementsByClassName(my_class);
    for (i = 0; i < x.length; i++) {  x[i].style.display = "none"; }
    document.getElementById(id).style.display = "block";
}
////////////////////////////////////////////////99999999999999999999999
 
 